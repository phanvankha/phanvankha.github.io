<?php

class Config{
    public function connect(){
        $hostname = "uddvxqfy_vkha";
        $username = "uddvxqfy_vkha";
        $password = "uddvxqfy_vkha";
        $dbname = "uddvxqfy_vkha";

        $conn = mysqli_connect($hostname, $username, $password, $dbname);
        if(!$conn){
            echo "Lỗi kết nối Database".mysqli_connect_error();
        }
        return $conn;
    }
}